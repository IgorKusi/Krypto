module Model {
    exports pl.pkr.model;
}